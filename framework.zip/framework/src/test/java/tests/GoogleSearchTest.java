package tests;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pages.GoogleHomePage;
import static org.junit.Assert.assertTrue;

public class GoogleSearchTest extends BaseTest{
	private static final Logger logger = LoggerFactory.getLogger(GoogleSearchTest.class);
    @Test
    public void testGoogleSearch() {
        logger.info("Starting Google search test");
        GoogleHomePage googleHomePage = new GoogleHomePage(driver);
        googleHomePage.open();
        logger.info("Opened Google homepage");
        googleHomePage.enterSearchTerm("Selenium WebDriver");
        googleHomePage.submitSearch();
        logger.info("Submitted search term");
        assertTrue("Search results are not displayed", googleHomePage.isSearchResultsDisplayed());
        logger.info("Search results are displayed");
    }
}
